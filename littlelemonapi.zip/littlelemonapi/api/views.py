from django.contrib.auth.models import User, Group
from rest_framework import status, generics, filters, pagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import MenuItem, OrderItem, Order
from .permissions import IsCustomerOrDeliveryCrew, IsManager, IsCustomer, IsDeliveryCrew
from .serializers import MenuItemSerializer, OrderItemSerializer, OrderSerializer


class MenuItemListView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsAuthenticated]
    permission_classes_by_action = {
        'list': [IsCustomerOrDeliveryCrew, IsManager],
        'create': [IsManager],
    }
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'price', 'featured', 'category__title']
    ordering_fields = ['title', 'price', 'featured', 'category__title']
    pagination_class = pagination.PageNumberPagination


class MenuItemDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsAuthenticated]
    permission_classes_by_action = {
        'create': [IsManager],
        'retrieve': [IsCustomerOrDeliveryCrew, IsManager],
        'update': [IsManager],
        'destroy': [IsManager],
    }


class ManagerGroupUsersView(APIView):
    permission_classes = [IsManager]
    search_fields = ['first_name', 'last_name', 'email']
    ordering_fields = ['first_name', 'last_name', 'email']
    pagination_class = pagination.PageNumberPagination

    def get(self, request):
        managers = User.objects.filter(groups__name='Manager')
        return Response({'managers': list(managers.values())})

    def post(self, request):
        user_id = request.data.get('user_id')
        user = User.objects.get(pk=user_id)
        group, created = Group.objects.get_or_create(name='Manager')
        user.groups.add(group)
        return Response({'message': 'User added to Manager group'}, status=status.HTTP_201_CREATED)


class ManagerGroupUserDetailView(APIView):
    permission_classes = [IsManager]

    def delete(self, request, user_id):
        try:
            user = User.objects.get(pk=user_id)
            group = Group.objects.get(name='Manager')
            user.groups.remove(group)
            return Response({'message': 'User removed from Manager group'}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)


class DeliveryCrewGroupUsersView(APIView):
    permission_classes = [IsManager]
    search_fields = ['first_name', 'last_name', 'email']
    ordering_fields = ['first_name', 'last_name', 'email']
    pagination_class = pagination.PageNumberPagination

    def get(self, request):
        delivery_crew = User.objects.filter(groups__name='Delivery Crew')
        return Response({'delivery_crew': list(delivery_crew.values())})

    def post(self, request):
        user_id = request.data.get('user_id')
        user = User.objects.get(pk=user_id)
        group, created = Group.objects.get_or_create(name='Delivery Crew')
        user.groups.add(group)
        return Response({'message': 'User added to Delivery Crew group'}, status=status.HTTP_201_CREATED)


class DeliveryCrewGroupUserDetailView(APIView):
    permission_classes = [IsManager]

    def delete(self, request, user_id):
        try:
            user = User.objects.get(pk=user_id)
            group = Group.objects.get(name='Delivery Crew')
            user.groups.remove(group)
            return Response({'message': 'User removed from Delivery Crew group'}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)


class CartMenuItemsView(APIView):
    permission_classes = [IsCustomer]
    search_fields = ['menu_item__title', 'quantity', 'unit_price', 'price']
    ordering_fields = ['menu_item__title', 'quantity', 'unit_price', 'price']
    pagination_class = pagination.PageNumberPagination

    def get(self, request):
        current_user = request.user
        cart_items = OrderItem.objects.filter(user=current_user)
        serializer = OrderItemSerializer(cart_items, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = OrderItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'message': 'Menu item added to cart successfully'}, status=status.HTTP_201_CREATED)

    def delete(self, request):
        current_user = request.user
        cart_items = OrderItem.objects.filter(user=current_user)
        cart_items.delete()
        return Response({'message': 'All menu items deleted from the cart successfully'}, status=status.HTTP_200_OK)


class OrderListView(generics.ListCreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]
    permission_classes_by_action = {
        'list': [IsCustomerOrDeliveryCrew, IsManager],
        'create': [IsCustomer],
    }
    search_fields = ['status', 'total', 'date']
    ordering_fields = ['status', 'total', 'date']
    pagination_class = pagination.PageNumberPagination


class OrderDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = OrderSerializer
    permission_classes_by_action = {
        'create': [IsManager],
        'retrieve': [IsCustomer],
        'update': [IsManager, IsDeliveryCrew],
        'delete': [IsManager]
    }
