from rest_framework import permissions
from rest_framework.permissions import IsAuthenticated, IsAdminUser


# Permission classes for different roles
class IsCustomerOrDeliveryCrew(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and (
                request.user.role == 'customer' or request.user.role == 'delivery_crew'
        )


class IsCustomer(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'customer'


class IsDeliveryCrew(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'delivery_crew'


class IsManager(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'manager'
