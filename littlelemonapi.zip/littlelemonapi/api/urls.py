from django.urls import path, include
from djoser.urls.base import router
from djoser.views import UserViewSet, TokenCreateView
from api import views

router.register(r'', UserViewSet)

urlpatterns = [
    path('', include(router.urls), name='user-view'),
    path('token/login', TokenCreateView.as_view(), name='token-create'),
    path('menu-items', include([
        path('', views.MenuItemListView.as_view()),
        path('/<int:pk>', views.MenuItemDetailView.as_view())
    ])),
    path('groups', include([
        path('manager/users', include([
            path('', views.ManagerGroupUsersView.as_view()),
            path('/<int:pk>', views.ManagerGroupUserDetailView.as_view())
        ])),
        path('delivery-crew', include([
            path('', views.DeliveryCrewGroupUsersView.as_view()),
            path('/<int:pk>', views.DeliveryCrewGroupUserDetailView.as_view())
        ]))
    ])),
    path('cart/menu-items', views.CartMenuItemsView.as_view()),
    path('orders', include([
        path('', views.OrderListView.as_view()),
        path('/<int:pk>', views.OrderDetailView.as_view())
    ]))
]